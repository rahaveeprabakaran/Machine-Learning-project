unzip dataset.zip before executing

