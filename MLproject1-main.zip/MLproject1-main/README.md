# old_files

Files for project written in Tensorflow, use as reference for earlier ideas.

# pytorch

Files for project written in PyTorch, currently being worked on. 
